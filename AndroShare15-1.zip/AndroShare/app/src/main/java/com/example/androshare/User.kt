package com.example.androshare

class User constructor(
    givenName: String,
    familyName: String,
    email: String,
    id: String
) {
    public var givenName : String? = givenName
    public var familyName: String? = familyName
    public var email: String = email
    public var id: String = id


}